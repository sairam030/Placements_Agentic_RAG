"""Streamlit chatbot interface for Placement RAG Agent."""

import streamlit as st
import sys
import os
import time

# Add parent directory to path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from agent.orchestrator import create_agent, PlacementAgent

# Page configuration
st.set_page_config(
    page_title="Placement Assistant",
    page_icon="🎓",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Custom CSS
st.markdown("""
<style>
    .main-header {
        font-size: 2.5rem;
        font-weight: bold;
        color: #1E88E5;
        text-align: center;
        margin-bottom: 1rem;
    }
    .sub-header {
        font-size: 1.2rem;
        color: #666;
        text-align: center;
        margin-bottom: 2rem;
    }
    .chat-message {
        padding: 1rem;
        border-radius: 0.5rem;
        margin-bottom: 1rem;
    }
    .user-message {
        background-color: #E3F2FD;
        border-left: 4px solid #1E88E5;
    }
    .assistant-message {
        background-color: #F5F5F5;
        border-left: 4px solid #4CAF50;
    }
    .confidence-high {
        color: #4CAF50;
    }
    .confidence-medium {
        color: #FFC107;
    }
    .confidence-low {
        color: #F44336;
    }
    .metric-card {
        background-color: #fff;
        padding: 1rem;
        border-radius: 0.5rem;
        box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    }
    .stTextInput > div > div > input {
        font-size: 1.1rem;
    }
</style>
""", unsafe_allow_html=True)


@st.cache_resource
def load_agent():
    """Load and cache the placement agent."""
    with st.spinner("🔄 Loading AI Agent... (this may take a minute)"):
        agent = create_agent(use_llm=True)
    return agent


def get_confidence_color(confidence: float) -> str:
    """Get color class based on confidence score."""
    if confidence >= 0.7:
        return "confidence-high"
    elif confidence >= 0.4:
        return "confidence-medium"
    else:
        return "confidence-low"


def get_confidence_emoji(confidence: float) -> str:
    """Get emoji based on confidence score."""
    if confidence >= 0.7:
        return "🟢"
    elif confidence >= 0.4:
        return "🟡"
    else:
        return "🔴"


def display_chat_history():
    """Display chat history."""
    for message in st.session_state.messages:
        role = message["role"]
        content = message["content"]
        
        if role == "user":
            with st.chat_message("user", avatar="👤"):
                st.markdown(content)
        else:
            with st.chat_message("assistant", avatar="🤖"):
                st.markdown(content)
                
                # Show metadata if available
                if "metadata" in message:
                    meta = message["metadata"]
                    conf = meta.get("confidence", 0)
                    emoji = get_confidence_emoji(conf)
                    
                    col1, col2, col3 = st.columns(3)
                    with col1:
                        st.caption(f"{emoji} Confidence: {conf:.0%}")
                    with col2:
                        st.caption(f"⏱️ Time: {meta.get('time', 0):.2f}s")
                    with col3:
                        st.caption(f"🔄 Retries: {meta.get('retries', 0)}")


def main():
    """Main Streamlit app."""
    
    # Header
    st.markdown('<p class="main-header">🎓 Placement Assistant</p>', unsafe_allow_html=True)
    st.markdown('<p class="sub-header">Ask me anything about internships and placements!</p>', unsafe_allow_html=True)
    
    # Sidebar
    with st.sidebar:
        st.markdown("## ⚙️ Settings")
        
        # Show available companies
        if st.checkbox("Show Available Companies", value=False):
            agent = load_agent()
            companies = agent.get_companies()
            st.markdown(f"**{len(companies)} companies in database:**")
            
            # Group in columns
            companies_text = ", ".join(sorted(companies)[:30])
            st.caption(companies_text)
            if len(companies) > 30:
                st.caption(f"... and {len(companies) - 30} more")
        
        st.markdown("---")
        
        # Example queries
        st.markdown("## 💡 Example Queries")
        
        example_queries = [
            "What is the selection process for Dell?",
            "Which companies are hiring in Bangalore?",
            "What is the stipend offered by Intel?",
            "Compare Dell and Intel internships",
            "What skills are needed for data science roles?",
            "List companies with stipend more than 50000",
        ]
        
        for query in example_queries:
            if st.button(query, key=f"example_{query[:20]}", use_container_width=True):
                st.session_state.example_query = query
        
        st.markdown("---")
        
        # Clear chat button
        if st.button("🗑️ Clear Chat History", use_container_width=True):
            st.session_state.messages = []
            st.rerun()
        
        st.markdown("---")
        st.markdown("### ℹ️ About")
        st.markdown("""
        This assistant helps you find information about:
        - 📋 Company details & roles
        - 💰 Stipend information
        - 📍 Job locations
        - 🎯 Selection processes
        - 🛠️ Required skills
        - 📊 Company comparisons
        """)
    
    # Initialize chat history
    if "messages" not in st.session_state:
        st.session_state.messages = []
    
    # Load agent
    agent = load_agent()
    
    # Display chat history
    display_chat_history()
    
    # Handle example query from sidebar
    if "example_query" in st.session_state:
        user_input = st.session_state.example_query
        del st.session_state.example_query
        process_query(agent, user_input)
        st.rerun()
    
    # Chat input
    if user_input := st.chat_input("Ask about placements, internships, companies..."):
        process_query(agent, user_input)
        st.rerun()


def process_query(agent: PlacementAgent, user_input: str):
    """Process a user query and update chat history."""
    
    # Add user message
    st.session_state.messages.append({
        "role": "user",
        "content": user_input
    })
    
    # Get response
    start_time = time.time()
    
    try:
        response = agent.query(user_input, verbose=False)
        elapsed = time.time() - start_time
        
        # Add assistant message with metadata
        st.session_state.messages.append({
            "role": "assistant",
            "content": response.answer,
            "metadata": {
                "confidence": response.feedback.confidence_score,
                "time": elapsed,
                "retries": response.retries,
                "intent": response.plan.intent,
                "companies": response.plan.companies_mentioned
            }
        })
        
    except Exception as e:
        st.session_state.messages.append({
            "role": "assistant",
            "content": f"❌ Error: {str(e)}\n\nPlease try rephrasing your question.",
            "metadata": {
                "confidence": 0,
                "time": time.time() - start_time,
                "retries": 0
            }
        })


if __name__ == "__main__":
    main()
