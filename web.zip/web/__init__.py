"""Web interface package for placement RAG agent."""
