"""Evaluation package for testing the placement RAG agent."""
